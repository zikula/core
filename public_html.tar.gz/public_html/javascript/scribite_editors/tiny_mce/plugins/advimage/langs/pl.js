// PL lang variables
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('advimage',{
tab_general : 'Główne ustawienia',
tab_appearance : 'Widok',
tab_advanced : 'Zaawansowane',
general : 'Główne',
title : 'Tytuł',
preview : 'Podgląd',
constrain_proportions : 'Zachowaj proporcje',
langdir : 'Kierunek tekstu',
langcode : 'Kod języka',
long_desc : 'Długi opis linku',
style : 'Styl',
classes : 'Klasy',
ltr : 'Lewy do prawego',
rtl : 'Prawy do lewego',
id : 'Id',
image_map : 'Mapa obrazka',
swap_image : 'Podmiana obrazka',
alt_image : 'Alternatywny obrazek',
mouseover : 'gdy myszka nad obrazkiem',
mouseout : 'gdy myszka poza obrazkiem',
misc : 'Różne',
example_img : 'Przykładowy&nbsp;podgląd&nbsp;obrazka',
missing_alt : 'Czy jesteś pewien, że chcesz kontynuować bez zawarcia opisu obrazka? Niektórzy użytkownicy moga używać przeglądarek tekstowych, lub mieć ograniczenia na wyświetlanie grafik, a wtedy Twój obrazek pozostanie dla nich niewidoczny.'
});
