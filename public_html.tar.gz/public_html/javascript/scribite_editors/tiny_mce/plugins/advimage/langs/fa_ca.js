// CA_FR lang variables

tinyMCE.addToLang('',{
insert_image_alt2 : 'Titre de l\'image',
insert_image_onmousemove : 'Image alternative',
insert_image_mouseover : 'pour le �mouse over�',
insert_image_mouseout : 'pour le �mouse out�'
});
