// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('advimage',{
tab_general : 'Chung',
tab_appearance : 'Xuất hiện',
tab_advanced : 'Nâng cao',
general : 'Chung',
title : 'Tiêu đề',
preview : 'Xem trước',
constrain_proportions : 'Ràng buộc kích thước',
langdir : 'Hướng ngôn ngữ',
langcode : 'Bộ mã ngôn ngữ',
long_desc : 'Mô tả đầy đủ',
style : 'Kiểu',
classes : 'Lớp',
ltr : 'Trái sang phải',
rtl : 'Phải sang trái',
id : 'Id',
image_map : 'Bản đồ ảnh',
swap_image : 'Thay đổi ảnh',
alt_image : 'Ảnh thay thế',
mouseover : 'khi di chuột vào',
mouseout : 'khi di chuột ra ngoài',
misc : 'Linh tinh',
example_img : 'Ảnh&nbsp;xem&nbsp;trước',
missing_alt : 'Bạn có chắc bạn muốn tiếp tục mà không cần nhập vào mô tả ảnh? Không có mô tả sẽ hạn chế khả năng truy cập của những người sử dụng khuyết tật, hoặc những người sử dụng trình duyệt văn bản, hoặc xem trang này khi đã tắt chế độ hiển thị ảnh.'
});
