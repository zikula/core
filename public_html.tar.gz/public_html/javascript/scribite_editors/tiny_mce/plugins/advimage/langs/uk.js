// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Основні',
tab_appearance : 'Візуалізація',
tab_advanced : 'Розширені',
general : 'Головні',
title : 'Заголовок',
preview : 'Попередній перегляд',
constrain_proportions : 'Зберегти пропорції',
langdir : 'Опис мови',
langcode : 'Код мови',
long_desc : 'Повний опис',
style : 'Стилі',
classes : 'Класи',
ltr : 'Зліва направо',
rtl : 'Справа наліво',
id : 'Id',
image_map : 'Карта зображення',
swap_image : 'Підміна картинки',
alt_image : 'Альтернативне зображення',
mouseover : 'при наведенні миші',
mouseout : 'коли усуненні миші',
misc : 'Решта',
example_img : 'Візуалізація&nbsp;розташування&nbsp;картинки',
missing_alt : 'Продовжити без Опису Зображення? Без опису зображення може бути недоступно для користувачів, що використовують текстові браузери чи отключивших показ зображень.'
});
