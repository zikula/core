// SV lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Klistra in som vanlig text',
paste_text_title : 'Anv�nd CTRL+V p� ditt tangentbord f�r att klistra in i detta f�nster.',
paste_text_linebreaks : 'Spara radbrytningar',
paste_word_desc : 'Klistra in fr�n Word',
paste_word_title : 'Anv�nd CTRL+V p� ditt tangentbord f�r att klistra in i detta f�nster.',
selectall_desc : 'Markera allt'
});
