// SV lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Klistra in som vanlig text',
paste_text_title : 'Använd CTRL+V på ditt tangentbord för att klistra in i detta fönster.',
paste_text_linebreaks : 'Spara radbrytningar',
paste_word_desc : 'Klistra in från Word',
paste_word_title : 'Använd CTRL+V på ditt tangentbord för att klistra in i detta fönster.',
selectall_desc : 'Markera allt'
});
