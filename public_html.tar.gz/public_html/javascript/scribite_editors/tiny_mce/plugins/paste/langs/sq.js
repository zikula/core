// UK lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Kopjo si Text te paster',
paste_text_title : 'Perdor CTRL+V ne tastjere per te kopjuar tekstin ne dritare.',
paste_text_linebreaks : 'Ruaj thyerjet e linjave',
paste_word_desc : 'Kopjo nga MS Word',
paste_word_title : 'UPerdor CTRL+V ne tastjere per te kopjuar tekstin ne dritare.',
selectall_desc : 'Zgjidh te gjithe'
});