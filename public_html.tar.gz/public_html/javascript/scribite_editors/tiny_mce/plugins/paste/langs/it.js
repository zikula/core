/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Mar. 1st, 2007
 * TinyMCE Version : 2.1.0
 */

tinyMCE.addToLang('',{
paste_text_desc : 'Incolla come testo non formattato',
paste_text_title : 'Usa CTRL+V per incollare.',
paste_text_linebreaks : 'Mantieni interruzioni di riga',
paste_word_desc : 'Incolla da Word',
paste_word_title : 'Usa CTRL+V per incollare.',
selectall_desc : 'Seleziona tutto'
});
