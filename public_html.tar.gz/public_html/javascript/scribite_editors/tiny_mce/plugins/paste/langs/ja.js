// JA lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'テキストとして貼り付け',
paste_text_title : 'キーボードからCTRL+Vを押下してテキストを貼り付けます。',
paste_text_linebreaks : '改行を保持したまま',
paste_word_desc : 'Word文書として貼り付け',
paste_word_title : 'キーボードからCTRL+Vを押下してテキストを貼り付けます。',
selectall_desc : 'すべて選択する'
});
