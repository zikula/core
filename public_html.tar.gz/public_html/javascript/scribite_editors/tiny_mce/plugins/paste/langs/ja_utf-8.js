﻿// Japanese utf-8 variables

tinyMCE.addToLang('',{
paste_text_desc : '書式なしで貼り付け',
paste_text_title : '貼り付けのために、CTRL+V を押す',
paste_text_linebreaks : '行を保存',
paste_word_desc : 'ワードから貼り付け',
paste_word_title : '貼り付けのために、CTRL+V を押す',
selectall_desc : 'すべて選択'
});
