// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
paste_text_desc : 'Dán như văn bản đơn giản',
paste_text_title : 'Sử dụng tổ hợp phím CTRL+V để dán văn bản vào cửa sổ.',
paste_text_linebreaks : 'Giữ các ký tự xuống dòng',
paste_word_desc : 'Dán từ Word',
paste_word_title : 'Sử dụng tổ hợp phím CTRL+V để dán văn bản vào cửa sổ.',
selectall_desc : 'Chọn toàn bộ'
});
