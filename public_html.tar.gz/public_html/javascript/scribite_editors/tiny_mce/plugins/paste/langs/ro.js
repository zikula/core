// RO lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Lipe&#351;te ca text simplu',
paste_text_title : 'Folose&#351;te CTRL+V de pe tastatur&#259; pentru a lipi text &#238;n fereastr&#259;.',
paste_text_linebreaks : 'P&#259;streaz&#259; spa&#355;ierea r&#226;ndurilor',
paste_word_desc : 'Lipe&#351;te din Word',
paste_word_title : 'Folose&#351;te CTRL+V de pe tastatur&#259; pentru a lipi text &#238;n fereastr&#259;.',
selectall_desc : 'Selecteaz&#259; tot'
});
