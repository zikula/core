// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
paste_text_desc : 'Prilepi kot navadno besedilo',
paste_text_title : 'Uporabite CTRL+V na va&#353;i tipkovnici, da prilepite besedilo v okno.',
paste_text_linebreaks : 'Obdr&#382;i prelome vrstic',
paste_word_desc : 'Prilepi iz Word-a',
paste_word_title : 'Uporabite CTRL+V na va&#353;i tipkovnici, da prilepite besedilo v okno.',
selectall_desc : 'Ozna&#269;i vse'
});
