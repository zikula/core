// UK lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Вставити як простий текст',
paste_text_title : 'Використовуйте CTRL+V для вставки тексту в віконце.',
paste_text_linebreaks : 'Зберегти перенесення рядків',
paste_word_desc : 'Вставити з Word',
paste_word_title : 'Використовуйте CTRL+V для вставки тексту в віконце.',
selectall_desc : 'Виділити все'
});
