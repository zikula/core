﻿// SR lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Zalepite kao običan tekst',
paste_text_title : 'Koristite CTRL+V na tastaturi da bi zalepili tekst u prozor.',
paste_text_linebreaks : 'Zadržavanje preseka linija',
paste_word_desc : 'Kopiranje iz Worda',
paste_word_title : 'Koristite CTRL+V  na tastaturi da bi zalepili tekst u prozor.',
selectall_desc : 'Selektovanje svega'
});
