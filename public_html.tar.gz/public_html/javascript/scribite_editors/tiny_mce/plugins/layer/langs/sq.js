// UK lang variables

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Nderfut nje shtrese',
forward_desc : 'Leviz perpara',
backward_desc : 'Leviz prapa',
absolute_desc : 'Cakto pozicionimin absolut',
content : 'Shtrese e re...'
});