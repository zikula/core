// RO lang variables

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Inseeaz&#259; un nou strat',
forward_desc : 'Mut&#259; &#238;nainte',
backward_desc : 'Mut&#259; &#238;napoi',
absolute_desc : 'Comut&#259; pozi&#355;ionarea absolut&#259;',
content : 'Strat nou...'
});
