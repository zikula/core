// FI lang variables

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Lis&auml;&auml; uusi taso',
forward_desc : 'Liiku eteenp&auml;in',
backward_desc : 'Liiku taaksep&auml;in',
absolute_desc : 'Kytke absoluuttinen asettelu p&auml;&auml;lle/pois',
content : 'Uusi taso...'
});
