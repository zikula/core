// UK lang variables

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Вставити новий шар',
forward_desc : 'Перемістити вперед',
backward_desc : 'Перемістити назад',
absolute_desc : 'Вкл / Відкл абсолютне позиціонування',
content : 'Новий шар...'
});
