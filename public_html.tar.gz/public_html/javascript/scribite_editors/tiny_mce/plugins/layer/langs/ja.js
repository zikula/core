// JA lang variables

tinyMCE.addToLang('layer',{
insertlayer_desc : '新しいレイヤーの挿入',
forward_desc : '前へ',
backward_desc : '奥へ',
absolute_desc : 'position属性の切り替え',
content : '新規レイヤー'
});
