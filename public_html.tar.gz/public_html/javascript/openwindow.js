/*
// ----------------------------------------------------------------------
// Original Author of file: phpBB team
// Purpose of file: bbcode javascript
// ----------------------------------------------------------------------
*/
function openwindow(hlpfile)
{
	window.open (hlpfile,"Help","toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=no,copyhistory=no,width=600,height=400");
}
