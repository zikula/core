<?php
require_once 'tla_lib.php';
tla_ads(311435,'SHOGQBF6Y62M3YDPJT46');

