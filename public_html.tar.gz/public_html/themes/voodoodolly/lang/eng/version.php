<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: version.php 24821 2008-11-05 16:01:47Z Guite $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author       Mark West
 * @package      Zikula_Themes
 * @subpackage   voodoodolly
 */

define('_VOODOODOLLY_DISPLAYNAME', 'VoodooDolly');
define('_VOODOODOLLY_DESCRIPTION', 'The \'Voodoo Dolly\' theme - a conservative but Web 2.0 look and feel, ready to go.');
