<?php
$themeversion['name'] = 'VoodooDolly';
$themeversion['displayname'] = __('VoodooDolly');
$themeversion['version'] = '1.0';
$themeversion['description'] = __("The VoodooDolly theme is a conservative browser-oriented theme with a Web 2.0 look and feel.");
$themeversion['regid'] = '0';
$themeversion['version'] = '1.0';
$themeversion['official'] = '1';
$themeversion['author'] = 'Mark West, pogy366';
$themeversion['contact'] = 'http://www.markwest.me.uk, http://www.dbfnetwork.info/rayk/index.html';
$themeversion['admin'] = 0;
$themeversion['user'] = 1;
$themeversion['system'] = 0;
$themeversion['credits'] = '';
$themeversion['help'] = '';
$themeversion['changelog'] = '';
$themeversion['license'] = '';
$themeversion['xhtml'] = true;
