<?php
$themeversion['name'] = 'Printer';
$themeversion['displayname'] = __('Printer');
$themeversion['description'] = __('The Printer theme is an auxiliary theme designed specially for outputting pages in a printer-friendly format.');
$themeversion['regid'] = '0';
$themeversion['version'] = '2.0';
$themeversion['official'] = '0';
$themeversion['author'] = 'Mark West';
$themeversion['contact'] = 'http://www.markwest.me.uk';
$themeversion['admin'] = 0;
$themeversion['user'] = 0;
$themeversion['system'] = 1;
$themeversion['credits'] = '';
$themeversion['help'] = '';
$themeversion['changelog'] = '';
$themeversion['license'] = '';
$themeversion['xhtml'] = true;
