<?php
define('_ADDSTORY','Add Article');
define('_DOWNLOAD','Downloads');
define('_EMAILTOAFRIEND', 'E-mail to a friend');
define('_FAQ','FAQ');
define('_FORUMS','Forums');
define('_GROUPADMIN','Groups');
define('_HOME','Home');
define('_PERMISSIONS', 'Permissions');
define('_PRINTTHISSTORY', 'Print this article');
define('_PUBLISHED', 'Published');
define('_REVIEWS','Reviews');
define('_SETTINGS','Settings');
define('_USERADMIN','User Admin');
define('_WORDSMORE', 'more word(s)');
define('_NICKNAME', 'Username');
define('_REMEMBERME', 'Remember Me');
define('_THEMEBY', 'Theme by <a href="http://www.ithinkmedia.com">iThinkMedia.com</a>');
