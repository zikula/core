<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: version.php 18415 2006-03-30 09:40:18Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author       Mark West
 * @package      Zikula_Themes
 * @subpackage   rss
 */

define('_RSSTHEME_SHOWDESCRIPTION', 'Show item descriptions');
define('_RSSTHEME_RSSLEVEL', 'RSS Level');
