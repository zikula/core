<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: version.php 24821 2008-11-05 16:01:47Z Guite $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author       Mark West
 * @package      Zikula_Themes
 * @subpackage   andreas08
 */

define('_ANDREAS08_DISPLAYNAME', 'Andreas08');
define('_ANDREAS08_DESCRIPTION', 'The \'Andreas08\' theme - a very good template for light, CSS-compatible themes.');
