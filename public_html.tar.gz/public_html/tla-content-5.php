<?php
include_once 'tla_lib.php';
tla_ads(311426, '12992HRBI9BTF4TQKSYQ');

