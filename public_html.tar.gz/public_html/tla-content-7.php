<?php
include_once 'tla_lib.php';
tla_ads(311432, '67N3DKBKPJG31VN9IE6E');

