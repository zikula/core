<?php
include_once 'tla_lib.php';

tla_ads(289140,'PCEWC2ZN27G7G6Q92U83');

